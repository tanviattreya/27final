﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace TheMatch.Models
//{
//    public class MockUserRepository
//    {
//        public IEnumerable<User> AllUsers =>
//            new List<User>
//            {
//                new User {Id = 1, Name="abc def", Age=22, Gender="Male", Bio="Hey There!", ImageUrl="https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg", ImageThumbnailUrl="https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg"},
//                new User {Id = 2, Name="ghi jkl", Age=35, Gender="Female", Bio="I am a big foodie!", ImageUrl="https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", ImageThumbnailUrl="https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small"},
//                new User {Id = 3, Name="mno pqr", Age=28, Gender="Female", Bio="I love books!", ImageUrl="https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80", ImageThumbnailUrl="https://images.unsplash.com/flagged/photo-1564149096159-4f8c72529ac8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80small"},
//                new User {Id = 4, Name="stu vwx", Age=30, Gender="Male", Bio="I love adventures!", ImageUrl="https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvP.jpeg",ImageThumbnailUrl="https://pbs.twimg.com/profile_images/485887758284513280/rxppLhvPsmall.jpeg"}   };


//        public User GetUserById(int Id)
//        {
//            return AllUsers.FirstOrDefault(p => p.Id == Id);
//        }
//    }
//}
