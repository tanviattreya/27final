﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TheMatch.Models
{
    public class UserRepository : IUserRepository
    {
        private readonly UserContext _UserContext;
        public UserRepository(UserContext userContext)
        {
            _UserContext = userContext;
        }

        public IEnumerable<User> AllUser => _UserContext.Users;
    }
}
