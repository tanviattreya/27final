﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TheMatch.Models
{
    public class MyProfile
    {
        [Key]
        public long MyId { get; set; }
        public long MyMail { get; set; }
        public string MyName { get; set; }
        public int MyAge { get; set; }
        public string MyGender { get; set; }
        public string MyBio { get; set; }
        public string MySexual_orientation { get; set; }
        public string MyImageUrl { get; set; }
        public string MyImageThumbnailUrl { get; set; }
    }
}
