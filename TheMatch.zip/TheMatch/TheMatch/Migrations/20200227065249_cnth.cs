﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TheMatch.Migrations
{
    public partial class cnth : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
